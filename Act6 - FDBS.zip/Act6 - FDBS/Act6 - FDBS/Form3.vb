﻿Imports MySql.Data.MySqlClient
Public Class Form3
    Dim CONNECT As MySqlConnection
    Dim CONSTRING As String = "data source = localhost; user id = root; database = votingsystem_pacadalhin"
    Dim CMD As MySqlCommand
    Dim DA As MySqlDataAdapter
    Dim DS As DataSet
    Dim itemcoll(999) As String

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            CONNECT = New MySqlConnection(CONSTRING)
            CONNECT.Open()
            Dim SQL As String = "Insert INTO party_list (Partylist_Number, Partylist_name) values ('" & TextBox1.Text & "', '" & TextBox2.Text & "')"
            CMD = New MySqlCommand(SQL, CONNECT)
            Dim i As Integer = CMD.ExecuteNonQuery
            If i <> 0 Then
                MsgBox("Done Voting!", vbInformation, "Admin")
            Else
                MsgBox("Record Not Saved", vbInformation, "Admin")
            End If
            Call LOADLV()
            CONNECT.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If TextBox1.Text = "1" Then
            TextBox2.Text = "1st year Partylist"
        ElseIf TextBox1.Text = "2" Then
            TextBox2.Text = "2nd Year Partylist"
        ElseIf TextBox1.Text = "3" Then
            TextBox2.Text = "3rd Year Partylist"
        Else
            MsgBox("Error")
        End If
    End Sub

    Public Sub LOADLV()
        Try
            ListView1.Items.Clear()
            CONNECT = New MySqlConnection(CONSTRING)
            CONNECT.Open()
            Dim SQL As String = "select * from party_list"
            CMD = New MySqlCommand(SQL, CONNECT)
            DA = New MySqlDataAdapter(CMD)
            DS = New DataSet
            DA.Fill(DS, "Tables")
            For r = 0 To DS.Tables(0).Rows.Count - 1
                For c = 0 To DS.Tables(0).Columns.Count - 1
                    itemcoll(c) = DS.Tables(0).Rows(r)(c).ToString
                Next
                Dim lvitm As New ListViewItem(itemcoll)
                ListView1.Items.Add(lvitm)
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        CONNECT.Close()
    End Sub

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call LOADLV()
    End Sub
End Class