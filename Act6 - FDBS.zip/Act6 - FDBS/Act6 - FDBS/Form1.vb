﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Dim CONNECT As MySqlConnection
    Dim CONSTRING As String = "data source = localhost; user id = root; database = votingsystem_pacadalhin"
    Dim CMD As MySqlCommand
    Dim DA As MySqlDataAdapter
    Dim DS As DataSet
    Dim itemcoll(999) As String


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            CONNECT = New MySqlConnection(CONSTRING)
            CONNECT.Open()
            Dim SQL As String = "Insert INTO voters (Student_Number, First_name, Last_name, Middle_name, Course, Year_Section, Email) values ('" & Studentnum.Text & "', '" & TextBox2.Text & "', '" & TextBox3.Text & "', '" & TextBox4.Text & "', '" & TextBox5.Text & "', '" & TextBox6.Text & "', '" & TextBox7.Text & "')"
            CMD = New MySqlCommand(SQL, CONNECT)
            Dim i As Integer = CMD.ExecuteNonQuery
            If i <> 0 Then
                MsgBox("Record Saved", vbInformation, "Admin")
            Else
                MsgBox("Record Not Saved", vbInformation, "Admin")
            End If
            Call LOADLV()
            CONNECT.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Public Sub LOADLV()
        Try
            ListView1.Items.Clear()
            CONNECT = New MySqlConnection(CONSTRING)
            CONNECT.Open()
            Dim SQL As String = "select * from voters"
            CMD = New MySqlCommand(SQL, CONNECT)
            DA = New MySqlDataAdapter(CMD)
            DS = New DataSet
            DA.Fill(DS, "Tables")
            For r = 0 To DS.Tables(0).Rows.Count - 1
                For c = 0 To DS.Tables(0).Columns.Count - 1
                    itemcoll(c) = DS.Tables(0).Rows(r)(c).ToString
                Next
                Dim lvitm As New ListViewItem(itemcoll)
                ListView1.Items.Add(lvitm)
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        CONNECT.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        If ListView1.SelectedItems.Count > 0 Then
            Studentnum.Text = ListView1.Items(ListView1.SelectedIndices(0)).SubItems(0).Text
            TextBox2.Text = ListView1.Items(ListView1.SelectedIndices(0)).SubItems(1).Text
            TextBox3.Text = ListView1.Items(ListView1.SelectedIndices(0)).SubItems(2).Text
            TextBox4.Text = ListView1.Items(ListView1.SelectedIndices(0)).SubItems(3).Text
            TextBox5.Text = ListView1.Items(ListView1.SelectedIndices(0)).SubItems(4).Text
            TextBox6.Text = ListView1.Items(ListView1.SelectedIndices(0)).SubItems(5).Text
            TextBox7.Text = ListView1.Items(ListView1.SelectedIndices(0)).SubItems(6).Text
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            CONNECT = New MySqlConnection(CONSTRING)
            CONNECT.Open()
            Dim SQL As String = "Update voters set First_Name = '" & TextBox2.Text & "',  Last_Name = '" & TextBox3.Text & "', Middle_Name = '" & TextBox4.Text & "', Course = '" & TextBox5.Text & "', Year_Section = '" & TextBox6.Text & "',  EMail = '" & TextBox7.Text & "' where Student_Number = '" & Studentnum.Text & "'"
            CMD = New MySqlCommand(SQL, CONNECT)
            Dim i As Integer = CMD.ExecuteNonQuery
            If i <> 0 Then
                MsgBox("Record Updated", vbInformation, "Admin")
            Else
                MsgBox("Record Cannot Be Updated", vbInformation, "Admin")
            End If
            Call LOADLV()
            CONNECT.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call LOADLV()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Studentnum.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox7.Clear()

    End Sub
End Class
